let searchButton = document.querySelector("#search")
searchButton.addEventListener("click", () => {
    console.log("button pressed")
    sendApiRequest()
})

async function sendApiRequest() {
    let APP_ID = "148d7a28"
    let API_KEY = "ba4e01b7315cae5c5f14aa1b7f361b47"
    let response = await fetch(`https://api.edamam.com/search?app_id=${APP_ID}&app_key=${API_KEY}&q=pizza`);
    console.log(response)
    let data = await response.json()
    console.log(data)
    useApiData(data)

}


function useApiData(data) {
    document.querySelector("#content").innerHTML = `
    <div class="card" style="width: 18rem;">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
  </div>
`
}